/*
* @Author: spatl
* @Date:   2016-11-30 15:39:28
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:52:03
*/

'use strict';

function decorator($delegate, $sce, $parse, $compile) {

  /**
   * Override angular ng-bind-html directive 
   */

  $delegate[0].compile = function ngBindHtmlCompile(tElement, tAttrs) {
    var ngBindHtmlGetter = $parse(tAttrs.ngBindHtml);
    var ngBindHtmlWatch = $parse(tAttrs.ngBindHtml, function getStringValue(value) {
      return (value || '').toString();
    });
    $compile.$$addBindingClass(tElement);

    return function ngBindHtmlLink(scope, element, attr) {
      $compile.$$addBindingInfo(element, attr.ngBindHtml);

      scope.$watch(ngBindHtmlWatch, function ngBindHtmlWatchAction() {
        /* 
        - Original code
        element.html($sce.getTrustedHtml(ngBindHtmlGetter(scope)) || '');
        */
       
        // Modified - Ignore sce and compile the content with parent scope
        element.html(ngBindHtmlGetter(scope));       
        $compile(element.contents())(scope);
      });
    };
  }

  return $delegate;

}

decorator.$inject = ['$delegate', '$sce', '$parse', '$compile'];

module.exports= decorator;