/*
* @Author: spatl
* @Date:   2016-11-30 15:39:42
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:51:39
*/

'use strict';

function config($provide, $compileProvider, $logProvider, $locationProvider, $stateProvider, $urlRouterProvider) {
  var env;

  if(window.__env__) env = angular.copy(window.__env__)
  else console.error('Environment file is missing.')

  $provide.constant('api', env.api);
  $compileProvider.debugInfoEnabled(env.debug);
  $logProvider.debugEnabled(env.debug);

  $urlRouterProvider.otherwise('/countries-setup');
  $stateProvider.state('countries-setup', {
    url: '/countries-setup',
    templateUrl: '$view/countries-setup/countries-setup.html',
    controller: 'countriesSetupCtrl',
    controllerAs: 'vm'
  }).state('product-setup', {
    url: '/product-setup',
    templateUrl: '$view/product-setup/product-setup.html',
    controller: 'productSetupCtrl',
    controllerAs: 'vm'
  });
}

config.$inject = ['$provide', '$compileProvider', '$logProvider', '$locationProvider',
'$stateProvider', '$urlRouterProvider'];

module.exports= config;
