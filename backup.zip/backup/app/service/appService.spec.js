/*
* @Author: spatl
* @Date:   2016-11-30 15:38:18
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:53:10
*/

'use strict';
describe('service: appService', function() {
  
  var rootScope, appService;

  before(function(){
    fixture.setBase('mock-data');
  });

  // Call beforeEach with mock. This is For browserify.
  beforeEach(angular.mock.module('aeApp'));

  beforeEach(
    inject(function($q, $rootScope, $httpBackend, _appService_, _api_){
      rootScope = $rootScope.$new();
      appService = _appService_;

      // Create a request with mock data
      $httpBackend.when('GET', _api_.main).respond( fixture.load('bento-main-app-data.json') );
      appService.request();
      $httpBackend.flush(); 
    })

  );
   
  it('appService: Should get all Platinum charge card', function() {
    appService.getCardDataById('platinum_charge').id.should.equal('platinum_charge');
  });


  it('appService: Should get hero-banner data', function() {
    appService.getComponentData('hero-banner').name.should.equal('hero-banner');
  });

});