/*
* @Author: spatl
* @Date:   2016-11-30 15:38:03
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:52:51
*/

'use strict';

/**
 * Refactoring note:
 * Do we need a resource? This app does not support CRUD. 
 * Can we use HTML5 base tag?
 */


function service($log, $q, $http, $window, api, util) {
  var data, allCardsDataCache, componentDataCache, param, selectedCardId, comparedCardItems;
  componentDataCache = [];

  // Param map
  param = {
    cardId         : 'card_id',
    compareCardIds : 'card'
  }

  /*==================================
  =            Initialize            =
  ==================================*/
  function init() {
    if(selectedCardId) return selectedCardId;
    selectedCardId = util.getUrlParam()[param.cardId] || undefined;
  }
  init();

  /*=====================================
  =            Public methods            =
  =====================================*/

  /**
   * Request to get data. Will have more desc when everything is ready
   * @return {[obj]} 
   */
  function request() {
    var deferred, reqUrl;
    deferred = $q.defer();

    // Define reqUrl

    reqUrl = (selectedCardId) ? api.cardDetail + '?' + param.cardId + '=' + selectedCardId : api.main;
    
    $http({
        method: 'get',
        url: reqUrl,
        responseType: 'JSON',
        timeout: 10000
      })
      .then(
        function(res) {
          data = res.data;
          return deferred.resolve(data);
        },
        function(err) {
          return deferred.reject(err);
        }
      )

    return deferred.promise;
  }

  /**
   * Return component data by name
   * @param  {[str]} componentDataCache[name] [Find a component data by name, remove target item from item from Array to save loop time, but save the copy into componentDataCache array]
   * @return {[obj]}                          []
   */
  function getComponentData(name) {
    if(componentDataCache[name] === undefined) {
      for(var key in data.component){
        if (data.component[key].name === name) {
          componentDataCache[name] = data.component[key];
          data.component.splice(key, 1)
          break;
        }
      }
    }
    return componentDataCache[name]
  }

  /**
   * Return all card data
   * @param   {[Argument]} [optional, service will return values only w/ provided keyname]
   * @return {[Arr]} [card data array]
   */
  function getAllCardData() {
    var i, selectedKeyName, key, cards, result; 
    i               = 0;
    selectedKeyName = Array.prototype.slice.call(arguments);
    cards           = data.global_data.card_mapping;
    result          = [];

    // Return cached array if it's available
    if(allCardsDataCache && selectedKeyName.length === 0) return allCardsDataCache;


    for(key in cards) {
      if(selectedKeyName.length === 0) {
        result[i] = cards[key];
      }
      else {
        populateDataBySelectedKey(i);
      }
      i++;
    }

    function populateDataBySelectedKey(i) {
        var card = {}; 
        selectedKeyName.forEach(function(v){ card[v] = cards[key][v] });
        result[i] = card;
    }

    // Create allCards Data Cache 
    if(!allCardsDataCache && selectedKeyName.length === 0) allCardsDataCache = result;
    return result;
  }

  /**
   * Return single card detail data by card id
   * @param  {[str]} cardId [pre-defined card id from market]
   * @return {[obj]}        [target card detail]
   */
  function getCardDataById(cardId) {
    return data.global_data.card_mapping[cardId] || {error: 'No card data found with id value ' + cardId}
  }

  /**
   * Return selected card data by card id from parameter
   * @return {[obj]} target card detail
   */
  function getSelectedCardData() {
    return data.global_data.card_mapping[selectedCardId] || {error: 'No card data found with id value ' + selectedCardId}
  }

  /**
   * Return formatted learn more url or index url of target card
   * Note: The query string will be replaced with permalinks when backend is ready
   * @param  {[str]} cardId [id of target card. Return index url if it's undefined ]
   * @param  {[str]} param [optional param append to url] // TEMP
   * @return {[str]}
   */
  function getLearnMoreUrlById(cardId, _param) {
    var url, comparedCardParam;
    url = (cardId) ? '?' + param.cardId + '=' + cardId : '';
    // append card ids for comparision
    if (comparedCardItems !== undefined){
      comparedCardParam = comparedCardItems.map(
        function(a,i) { 
          return ( (i===0 && url==='')? '?' : '&') + param.compareCardIds + '=' + a;
        }).join('');
    }
    return url + (comparedCardParam || '');
  }

  /**
   * Get ids of compared card items from url parameter
   * @return {[type]} [description]
   */
  function getComparedCardItems() {
    var _param = util.getUrlParam()[param.compareCardIds];
    if (_param === undefined || _param === '') return [];
    return (typeof _param === 'string') ? [_param] : _param;
  }

  /**
   * Set updated ids of compared card item 
   * @param {[type]} arr [description]
   */
  function setComparedCardItems(arr) {
    comparedCardItems = arr;
  }


  return {
    request              : request,
    getComponentData     : getComponentData,
    getAllCardData       : getAllCardData,
    getCardDataById      : getCardDataById,
    getSelectedCardData  : getSelectedCardData,
    getLearnMoreUrlById  : getLearnMoreUrlById,
    getComparedCardItems : getComparedCardItems,
    setComparedCardItems : setComparedCardItems
  }

}

service.$inject = ['$log', '$q', '$http', '$window', 'api', 'util'];

module.exports= service;