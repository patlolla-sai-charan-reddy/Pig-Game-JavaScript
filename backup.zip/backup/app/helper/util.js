/*
* @Author: spatl
* @Date:   2016-11-30 15:38:51
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:52:26
*/

'use strict';

/**
 * Utility functions (factory)
 */


 function util($window) {
  return {

    templateLiteral: function(str, prop) {
      var template = str.split(/\${(.*?)}/).map(function(a) {
        for(var key in prop) {
          if (a === key) a = prop[key];
        }
        return a;
      })
      return template.join('');
    },

    getElementPosition: function(el) {
      var xPos, yPos;
      xPos = 0;
      yPos = 0;

      while (el) {
        if (el.tagName === 'BODY') {
          // deal with browser quirks with body/window/document and page scroll
          var xScroll = el.scrollLeft || document.documentElement.scrollLeft;
          var yScroll = el.scrollTop || document.documentElement.scrollTop;

          xPos += (el.offsetLeft - xScroll + el.clientLeft);
          yPos += (el.offsetTop - yScroll + el.clientTop);
        } else {
          // for all other non-BODY elements
          xPos += (el.offsetLeft - el.scrollLeft + el.clientLeft);
          yPos += (el.offsetTop - el.scrollTop + el.clientTop);
        }

        el = el.offsetParent;
      }
      return {
        x: xPos,
        y: yPos
      };
    },

    getUserMetaDetail: function() {
      var ua, info, M, D;
      ua   = navigator.userAgent;
      info = {};
      M    = ua.match(/(opera|chrome|safari|firefox|msie|trident(?=\/))\/?\s*(\d+)/i) || [],
      D    = ua.match(/Windows|Macintosh|Linux|Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini|AppleTV|GoogleTV|HbbTV|SmartTV|Roku|GTV100|SonyDTV|SonyBDP|LGE|Viera|Playstation/i)[0] || 'SmartDevice';
      /*
      Browser detection
      */

      // Detect MSIE 11 or higher
      if(/trident/i.test(M[1])){
        var v =  /\brv[ :]+(\d+)/g.exec(ua) || [];
        info.browser = 'Internet Explorer';
        info.version = v[1] || null;
      }
      // Detect MSIE 10 or lower
      else if (/msie/i.test(M[1])){
        info.browser = 'Internet Explorer';
        info.version = M[2];
      }
      // Detect Opera
      else if(M[1]=== 'Chrome' && ua.match(/\b(OPR|Edge)\/(\d+)/) !== null){
        info.browser = 'Opera';
        info.version = M[2];
      }
      else {
        info.browser = M[1];
        info.version = M[2];
      }

      /*
      Device detection
      */
      if(/Windows|Macintosh|Linux/i.test(D)) {
        info.type = 'Desktop';
      }
      else if(/Android|webOS|iPhone|iPod|BlackBerry|IEMobile|Opera Mini/i.test(D)) {
        info.type = 'Mobile';
      }
      else if(/iPad/i.test(D)) {
        info.type = 'Tablet';
      }
      else if(/AppleTV|GoogleTV|HbbTV|SmartTV|Roku|GTV100|SonyDTV|SonyBDP|LGE|Viera|Playstation/i.test(D)) {
        info.type = 'TV';
      }
      else {
        info.type = D;
      }

      info.userAgent = ua;

      return info;
    },

    getUrlParam: function() {
      var query, vars, param, i, key, val;
      query = $window.location.search.substring(1);
      vars  = query.split('&');
      param = [];
      for (i=0;i<vars.length; i++) {
        key = vars[i].split('=')[0];
        val = vars[i].split('=')[1];
        if (!!param[key]) {
          if (typeof param[key] === 'string') {
            param[key] = [param[key], val];
          }
          else {
            param[key].push(val)
          }
        }
        else {
          param[key] = val;
        }
      }
      return param;
    }

  }
}

util.$inject = ['$window'];

module.exports= util;