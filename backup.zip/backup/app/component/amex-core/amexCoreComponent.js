/*
* @Author: spatl
* @Date:   2016-11-30 15:48:06
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-05 14:58:20
*/

'use strict';

function controller($log, $scope, $element, $compile, $timeout, appService) {
    /**

    TODO:
    - Better error response
    - Unit test
    */

  var ctrl;
  ctrl           = this;
  ctrl.rootModel = {};

  /*==================================
  =            Initialize            =
  ==================================*/
  ctrl.$onInit = function() {
    ctrl.loading = true;
    appService.request().then(onRequestSuccess, onRequestError);
  }

  /*=================================
  =            Callbacks            =
  =================================*/
  function onRequestSuccess(res) {
    build(res.component);
  }

  function onRequestError(err) {
    ctrl.loading = false;
    $log.error(err);
  }

  /*=========================================
  =            Private functions            =
  =========================================*/

  /**
   * Compile components
   * @param  {[arr]} component [contains list of component datas as an object]
   */
  function build(component) {
    var template, main, delay;
    main  = $element.find('main');
    delay = component.length * 0;
    // Do compile
    component.forEach(function(c){
      // Create template string and append to main container
      template = [
        '<' + c.name + ' class="' + c.name + '" ',
        'show-alert      ="root.showAlert(text)" ',
        '></' + c.name + '>'
        ].join('');

      main.append($compile(template)($scope, function(elem){ $log.debug('> AmexCore - Compiling:', elem[0].tagName) }));
    });

    // Adding delay to complete page
    $timeout(function() {
      ctrl.loading = false;
    }, delay);
  }

  /*=================================
  =            Listeners            =
  =================================*/

  /**
   * Global scope for all component.
   * @param  {[obj]} model [model can have multiple properties]
   *
   * rootModel properties:
   * cardFilter               {[arr]} [contains filter values for filtering cards on screen. Some coponents are watching this scope to update its behavior.]
   * comparedCardItems        {[arr]} [contains ids of compared cards that currently selected. Some coponents are watching this scope to update its behavior.]
   * selectedComparedCardId   {[str]} [update this scope with card id when to add/remove target item from comparedCardItems list. Some coponents are watching this scope to update its behavior.]
   */
  ctrl.onUpdate = function(model) {
    var key, newModel;
    newModel = angular.copy(ctrl.rootModel);
    for (key in model) {
      newModel[key] = model[key];
    }
    ctrl.rootModel = newModel;
  }

  /**
   * Scope for alert component
   * @param  {[str]} text
   */
  ctrl.showAlert = function(text) {
    ctrl.alertText = {text:text};
  }

}

controller.$inject = ['$log', '$scope', '$element', '$compile', '$timeout', 'appService'];

module.exports= {
  templateUrl: '$view/amex-core/amexCoreComponent.html',
  controller: controller,
  controllerAs: 'root'
};
