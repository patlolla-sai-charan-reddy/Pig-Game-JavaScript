'use strict';

function controller($log, appService, $scope) {
  
}

controller.$inject = ['$log', '$scope', 'appService'];

module.exports = controller;
