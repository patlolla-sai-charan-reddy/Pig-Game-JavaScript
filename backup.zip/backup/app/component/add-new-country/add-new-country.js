'use strict';

function controller($log, $scope, $element, $attrs, appService) {

}

controller.$inject = ['$log', '$scope', '$element', '$attrs', 'appService'];

module.exports= {
  templateUrl: '$view/add-new-country/add-new-country.html',
  controller: controller,
  controllerAs: 'vm',
  bindings: {
      show: '=show'
  }
};
