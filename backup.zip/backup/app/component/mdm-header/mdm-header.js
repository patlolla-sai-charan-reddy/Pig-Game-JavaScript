'use strict';

function controller($log, $scope, $element, $attrs, appService) {

}

controller.$inject = ['$log', '$scope', '$element', '$attrs', 'appService'];

module.exports= {
  templateUrl: '$view/mdm-header/mdm-header.html',
  controller: controller,
  controllerAs: 'vm',
  bindings: {
  }
};
