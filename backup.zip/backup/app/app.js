/*
* @Author: spatl
* @Date:   2016-11-30 15:37:18
* @Last Modified by:   spatl
* @Last Modified time: 2016-12-06 09:57:50
*/

(function(){
  'use strict';

  var angular                   = require('angular'),
      angularAnimate            = require('angular-animate'),
      angularSanitize           = require('angular-sanitize'),
      angularRouter             = require('angular-route'),
      appConfig                 = require('./config/appConfig'),
      appService                = require('./service/appService'),
      util                      = require('./helper/util'),
      ngBindHtmlDirective       = require('./decorator/ngBindHtmlDirectiveDecorator'),
      amexCoreComponent         = require('./component/amex-core/amexCoreComponent'),
      heroBannerComponent       = require('./component/hero-banner/heroBannerComponent'),
      countriesSetupCtrl        = require('./component/countries-setup/countries-setup'),
      productSetupCtrl          = require('./component/product-setup/product-setup');
      mdmHeaderComponent        = require('./component/mdm-header/mdm-header');
      addNewCountryComponent    = require('./component/add-new-country/add-new-country');
      addNewProductComponent    = require('./component/add-new-product/add-new-product');

  angular
    .module('aeApp', ['ngAnimate', 'ngSanitize'])
    .config(appConfig)
    .controller('countriesSetupCtrl', countriesSetupCtrl)
    .controller('productSetupCtrl', productSetupCtrl)
    .factory('util', util)
    .factory('appService', appService)
    .decorator('ngBindHtmlDirective', ngBindHtmlDirective)
    .component('mdmHeader', mdmHeaderComponent)
    .component('amexCore', amexCoreComponent)
    .component('alert', alertComponent)
    .component('addNewCountry', addNewCountryComponent)
    .component('addNewProduct', addNewProductComponent)

})();
