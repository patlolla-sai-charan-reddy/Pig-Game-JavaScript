'use strict';

function appConfig($stateProvider, $urlRouterProvider) {
  $urlRouterProvider.otherwise('/countries-setup');
  $stateProvider.state('countries-setup', {
    url: '/countries-setup',
    templateUrl: 'countries-setup.html',
    controller: 'countriesSetupCtrl',
    controllerAs: 'vm'
  }).state('product-setup', {
    url: '/product-setup',
    templateUrl: 'product-setup.html',
    controller: 'productSetupCtrl',
    controllerAs: 'vm'
  });
}

appConfig.$inject = ['$stateProvider', '$urlRouterProvider'];

module.exports= appConfig;
